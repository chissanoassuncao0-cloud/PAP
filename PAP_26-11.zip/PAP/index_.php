<?php
    require_once "includes/db_connection.php";
?>
<!DOCTYPE html>
<html lang="pt-PT">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="templates/css/style.css">
</head>
<body>
    <script src="templates/js/script.js"></script>
    
</body>
</html>