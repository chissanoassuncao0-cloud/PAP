<?php
// includes/db_connection.php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Função de erro (só precisamos desta aqui)
// Ativa o modo de exceção do MySQLi
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    // Tenta estabelecer a conexão
    $banco = new mysqli('localhost', 'i243511', 'i243511', 'i243511_db_games');
    //$banco = new mysqli('localhost', 'i35344', 'i35344', 'i35344_db_games');
    $banco->set_charset("utf8");
    // NOTA: Não há mensagem de sucesso aqui.
    // O silêncio é o nosso sucesso.
} catch (mysqli_sql_exception $e) {
    // Se a conexão falhar, exibe o erro e PÁRA O SCRIPT.
    exibirErro($e->getMessage());
    exit();
}
// IMPORTANTE:
// NÃO execute $banco->query() aqui.
// NÃO execute $banco->close() aqui.
// Deixe a variável $banco "viva" para o index.php usar.
?>